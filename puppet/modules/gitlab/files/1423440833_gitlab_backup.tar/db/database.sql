--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: broadcast_messages; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE broadcast_messages (
    id integer NOT NULL,
    message text NOT NULL,
    starts_at timestamp without time zone,
    ends_at timestamp without time zone,
    alert_type integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    color character varying(255),
    font character varying(255)
);


ALTER TABLE public.broadcast_messages OWNER TO gitlab;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE broadcast_messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.broadcast_messages_id_seq OWNER TO gitlab;

--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE broadcast_messages_id_seq OWNED BY broadcast_messages.id;


--
-- Name: deploy_keys_projects; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE deploy_keys_projects (
    id integer NOT NULL,
    deploy_key_id integer NOT NULL,
    project_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.deploy_keys_projects OWNER TO gitlab;

--
-- Name: deploy_keys_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE deploy_keys_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.deploy_keys_projects_id_seq OWNER TO gitlab;

--
-- Name: deploy_keys_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE deploy_keys_projects_id_seq OWNED BY deploy_keys_projects.id;


--
-- Name: emails; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE emails (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.emails OWNER TO gitlab;

--
-- Name: emails_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE emails_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.emails_id_seq OWNER TO gitlab;

--
-- Name: emails_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE emails_id_seq OWNED BY emails.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE events (
    id integer NOT NULL,
    target_type character varying(255),
    target_id integer,
    title character varying(255),
    data text,
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    action integer,
    author_id integer
);


ALTER TABLE public.events OWNER TO gitlab;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_id_seq OWNER TO gitlab;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE events_id_seq OWNED BY events.id;


--
-- Name: forked_project_links; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE forked_project_links (
    id integer NOT NULL,
    forked_to_project_id integer NOT NULL,
    forked_from_project_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.forked_project_links OWNER TO gitlab;

--
-- Name: forked_project_links_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE forked_project_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.forked_project_links_id_seq OWNER TO gitlab;

--
-- Name: forked_project_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE forked_project_links_id_seq OWNED BY forked_project_links.id;


--
-- Name: identities; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE identities (
    id integer NOT NULL,
    extern_uid character varying(255),
    provider character varying(255),
    user_id integer
);


ALTER TABLE public.identities OWNER TO gitlab;

--
-- Name: identities_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identities_id_seq OWNER TO gitlab;

--
-- Name: identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE identities_id_seq OWNED BY identities.id;


--
-- Name: issues; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE issues (
    id integer NOT NULL,
    title character varying(255),
    assignee_id integer,
    author_id integer,
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    "position" integer DEFAULT 0,
    branch_name character varying(255),
    description text,
    milestone_id integer,
    state character varying(255),
    iid integer
);


ALTER TABLE public.issues OWNER TO gitlab;

--
-- Name: issues_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.issues_id_seq OWNER TO gitlab;

--
-- Name: issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE issues_id_seq OWNED BY issues.id;


--
-- Name: keys; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE keys (
    id integer NOT NULL,
    user_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    key text,
    title character varying(255),
    type character varying(255),
    fingerprint character varying(255)
);


ALTER TABLE public.keys OWNER TO gitlab;

--
-- Name: keys_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.keys_id_seq OWNER TO gitlab;

--
-- Name: keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE keys_id_seq OWNED BY keys.id;


--
-- Name: label_links; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE label_links (
    id integer NOT NULL,
    label_id integer,
    target_id integer,
    target_type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.label_links OWNER TO gitlab;

--
-- Name: label_links_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE label_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.label_links_id_seq OWNER TO gitlab;

--
-- Name: label_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE label_links_id_seq OWNED BY label_links.id;


--
-- Name: labels; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE labels (
    id integer NOT NULL,
    title character varying(255),
    color character varying(255),
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.labels OWNER TO gitlab;

--
-- Name: labels_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.labels_id_seq OWNER TO gitlab;

--
-- Name: labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE labels_id_seq OWNED BY labels.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE members (
    id integer NOT NULL,
    access_level integer NOT NULL,
    source_id integer NOT NULL,
    source_type character varying(255) NOT NULL,
    user_id integer NOT NULL,
    notification_level integer NOT NULL,
    type character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.members OWNER TO gitlab;

--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.members_id_seq OWNER TO gitlab;

--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE members_id_seq OWNED BY members.id;


--
-- Name: merge_request_diffs; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE merge_request_diffs (
    id integer NOT NULL,
    state character varying(255),
    st_commits text,
    st_diffs text,
    merge_request_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.merge_request_diffs OWNER TO gitlab;

--
-- Name: merge_request_diffs_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE merge_request_diffs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merge_request_diffs_id_seq OWNER TO gitlab;

--
-- Name: merge_request_diffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE merge_request_diffs_id_seq OWNED BY merge_request_diffs.id;


--
-- Name: merge_requests; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE merge_requests (
    id integer NOT NULL,
    target_branch character varying(255) NOT NULL,
    source_branch character varying(255) NOT NULL,
    source_project_id integer NOT NULL,
    author_id integer,
    assignee_id integer,
    title character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    milestone_id integer,
    state character varying(255),
    merge_status character varying(255),
    target_project_id integer NOT NULL,
    iid integer,
    description text,
    "position" integer DEFAULT 0,
    locked_at timestamp without time zone
);


ALTER TABLE public.merge_requests OWNER TO gitlab;

--
-- Name: merge_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE merge_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.merge_requests_id_seq OWNER TO gitlab;

--
-- Name: merge_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE merge_requests_id_seq OWNED BY merge_requests.id;


--
-- Name: milestones; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE milestones (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    project_id integer NOT NULL,
    description text,
    due_date date,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    state character varying(255),
    iid integer
);


ALTER TABLE public.milestones OWNER TO gitlab;

--
-- Name: milestones_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE milestones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.milestones_id_seq OWNER TO gitlab;

--
-- Name: milestones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE milestones_id_seq OWNED BY milestones.id;


--
-- Name: namespaces; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE namespaces (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    path character varying(255) NOT NULL,
    owner_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255),
    description character varying(255) DEFAULT ''::character varying NOT NULL,
    avatar character varying(255)
);


ALTER TABLE public.namespaces OWNER TO gitlab;

--
-- Name: namespaces_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE namespaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.namespaces_id_seq OWNER TO gitlab;

--
-- Name: namespaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE namespaces_id_seq OWNED BY namespaces.id;


--
-- Name: notes; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE notes (
    id integer NOT NULL,
    note text,
    noteable_type character varying(255),
    author_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    project_id integer,
    attachment character varying(255),
    line_code character varying(255),
    commit_id character varying(255),
    noteable_id integer,
    system boolean DEFAULT false NOT NULL,
    st_diff text
);


ALTER TABLE public.notes OWNER TO gitlab;

--
-- Name: notes_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE notes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notes_id_seq OWNER TO gitlab;

--
-- Name: notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE notes_id_seq OWNED BY notes.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE projects (
    id integer NOT NULL,
    name character varying(255),
    path character varying(255),
    description text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    creator_id integer,
    issues_enabled boolean DEFAULT true NOT NULL,
    wall_enabled boolean DEFAULT true NOT NULL,
    merge_requests_enabled boolean DEFAULT true NOT NULL,
    wiki_enabled boolean DEFAULT true NOT NULL,
    namespace_id integer,
    issues_tracker character varying(255) DEFAULT 'gitlab'::character varying NOT NULL,
    issues_tracker_id character varying(255),
    snippets_enabled boolean DEFAULT true NOT NULL,
    last_activity_at timestamp without time zone,
    import_url character varying(255),
    visibility_level integer DEFAULT 0 NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    import_status character varying(255),
    repository_size double precision DEFAULT 0.0,
    star_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.projects OWNER TO gitlab;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO gitlab;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE projects_id_seq OWNED BY projects.id;


--
-- Name: protected_branches; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE protected_branches (
    id integer NOT NULL,
    project_id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.protected_branches OWNER TO gitlab;

--
-- Name: protected_branches_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE protected_branches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.protected_branches_id_seq OWNER TO gitlab;

--
-- Name: protected_branches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE protected_branches_id_seq OWNED BY protected_branches.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO gitlab;

--
-- Name: services; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE services (
    id integer NOT NULL,
    type character varying(255),
    title character varying(255),
    project_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    active boolean DEFAULT false NOT NULL,
    properties text
);


ALTER TABLE public.services OWNER TO gitlab;

--
-- Name: services_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE services_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.services_id_seq OWNER TO gitlab;

--
-- Name: services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE services_id_seq OWNED BY services.id;


--
-- Name: snippets; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE snippets (
    id integer NOT NULL,
    title character varying(255),
    content text,
    author_id integer NOT NULL,
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    file_name character varying(255),
    expires_at timestamp without time zone,
    type character varying(255),
    visibility_level integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.snippets OWNER TO gitlab;

--
-- Name: snippets_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE snippets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.snippets_id_seq OWNER TO gitlab;

--
-- Name: snippets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE snippets_id_seq OWNED BY snippets.id;


--
-- Name: taggings; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE taggings (
    id integer NOT NULL,
    tag_id integer,
    taggable_id integer,
    taggable_type character varying(255),
    tagger_id integer,
    tagger_type character varying(255),
    context character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.taggings OWNER TO gitlab;

--
-- Name: taggings_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE taggings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.taggings_id_seq OWNER TO gitlab;

--
-- Name: taggings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE taggings_id_seq OWNED BY taggings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE tags (
    id integer NOT NULL,
    name character varying(255)
);


ALTER TABLE public.tags OWNER TO gitlab;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_id_seq OWNER TO gitlab;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE tags_id_seq OWNED BY tags.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying(255) DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying(255),
    reset_password_sent_at timestamp without time zone,
    remember_created_at timestamp without time zone,
    sign_in_count integer DEFAULT 0,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying(255),
    last_sign_in_ip character varying(255),
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    name character varying(255),
    admin boolean DEFAULT false NOT NULL,
    projects_limit integer DEFAULT 10,
    skype character varying(255) DEFAULT ''::character varying NOT NULL,
    linkedin character varying(255) DEFAULT ''::character varying NOT NULL,
    twitter character varying(255) DEFAULT ''::character varying NOT NULL,
    authentication_token character varying(255),
    theme_id integer DEFAULT 1 NOT NULL,
    bio character varying(255),
    failed_attempts integer DEFAULT 0,
    locked_at timestamp without time zone,
    username character varying(255),
    can_create_group boolean DEFAULT true NOT NULL,
    can_create_team boolean DEFAULT true NOT NULL,
    state character varying(255),
    color_scheme_id integer DEFAULT 1 NOT NULL,
    notification_level integer DEFAULT 1 NOT NULL,
    password_expires_at timestamp without time zone,
    created_by_id integer,
    last_credential_check_at timestamp without time zone,
    avatar character varying(255),
    confirmation_token character varying(255),
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    unconfirmed_email character varying(255),
    hide_no_ssh_key boolean DEFAULT false,
    website_url character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO gitlab;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO gitlab;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_star_projects; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE users_star_projects (
    id integer NOT NULL,
    project_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.users_star_projects OWNER TO gitlab;

--
-- Name: users_star_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE users_star_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_star_projects_id_seq OWNER TO gitlab;

--
-- Name: users_star_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE users_star_projects_id_seq OWNED BY users_star_projects.id;


--
-- Name: web_hooks; Type: TABLE; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE TABLE web_hooks (
    id integer NOT NULL,
    url character varying(255),
    project_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    type character varying(255) DEFAULT 'ProjectHook'::character varying,
    service_id integer,
    push_events boolean DEFAULT true NOT NULL,
    issues_events boolean DEFAULT false NOT NULL,
    merge_requests_events boolean DEFAULT false NOT NULL,
    tag_push_events boolean DEFAULT false
);


ALTER TABLE public.web_hooks OWNER TO gitlab;

--
-- Name: web_hooks_id_seq; Type: SEQUENCE; Schema: public; Owner: gitlab
--

CREATE SEQUENCE web_hooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.web_hooks_id_seq OWNER TO gitlab;

--
-- Name: web_hooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gitlab
--

ALTER SEQUENCE web_hooks_id_seq OWNED BY web_hooks.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY broadcast_messages ALTER COLUMN id SET DEFAULT nextval('broadcast_messages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY deploy_keys_projects ALTER COLUMN id SET DEFAULT nextval('deploy_keys_projects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY emails ALTER COLUMN id SET DEFAULT nextval('emails_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY events ALTER COLUMN id SET DEFAULT nextval('events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY forked_project_links ALTER COLUMN id SET DEFAULT nextval('forked_project_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY identities ALTER COLUMN id SET DEFAULT nextval('identities_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY issues ALTER COLUMN id SET DEFAULT nextval('issues_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY keys ALTER COLUMN id SET DEFAULT nextval('keys_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY label_links ALTER COLUMN id SET DEFAULT nextval('label_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY labels ALTER COLUMN id SET DEFAULT nextval('labels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY members ALTER COLUMN id SET DEFAULT nextval('members_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY merge_request_diffs ALTER COLUMN id SET DEFAULT nextval('merge_request_diffs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY merge_requests ALTER COLUMN id SET DEFAULT nextval('merge_requests_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY milestones ALTER COLUMN id SET DEFAULT nextval('milestones_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY namespaces ALTER COLUMN id SET DEFAULT nextval('namespaces_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY notes ALTER COLUMN id SET DEFAULT nextval('notes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY projects ALTER COLUMN id SET DEFAULT nextval('projects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY protected_branches ALTER COLUMN id SET DEFAULT nextval('protected_branches_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY services ALTER COLUMN id SET DEFAULT nextval('services_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY snippets ALTER COLUMN id SET DEFAULT nextval('snippets_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY taggings ALTER COLUMN id SET DEFAULT nextval('taggings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY tags ALTER COLUMN id SET DEFAULT nextval('tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY users_star_projects ALTER COLUMN id SET DEFAULT nextval('users_star_projects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: gitlab
--

ALTER TABLE ONLY web_hooks ALTER COLUMN id SET DEFAULT nextval('web_hooks_id_seq'::regclass);


--
-- Data for Name: broadcast_messages; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY broadcast_messages (id, message, starts_at, ends_at, alert_type, created_at, updated_at, color, font) FROM stdin;
\.


--
-- Name: broadcast_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('broadcast_messages_id_seq', 1, false);


--
-- Data for Name: deploy_keys_projects; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY deploy_keys_projects (id, deploy_key_id, project_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: deploy_keys_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('deploy_keys_projects_id_seq', 1, false);


--
-- Data for Name: emails; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY emails (id, user_id, email, created_at, updated_at) FROM stdin;
\.


--
-- Name: emails_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('emails_id_seq', 1, false);


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY events (id, target_type, target_id, title, data, project_id, created_at, updated_at, action, author_id) FROM stdin;
1	\N	\N	\N	\N	1	2015-01-19 02:03:13.644119	2015-01-19 02:03:13.644119	8	2
2	\N	\N	\N	---\n:before: '0000000000000000000000000000000000000000'\n:after: 0c118cfba876b98c2872d7e419bb0383782977ff\n:ref: refs/heads/master\n:user_id: 2\n:user_name: puppet\n:project_id: 1\n:repository:\n  :name: puppet-repository\n  :url: git@gitlab.local.vm:puppet/puppet-repository.git\n  :description: Puppet control repository\n  :homepage: http://gitlab.local.vm/puppet/puppet-repository\n:commits:\n- :id: 0c118cfba876b98c2872d7e419bb0383782977ff\n  :message: |\n    initial commit\n  :timestamp: '2015-01-18T18:08:01-08:00'\n  :url: http://gitlab.local.vm/puppet/puppet-repository/commit/0c118cfba876b98c2872d7e419bb0383782977ff\n  :author:\n    :name: puppet\n    :email: puppet@gitlab.local\n:total_commits_count: 1\n	1	2015-01-19 02:08:15.034639	2015-01-19 02:08:15.034639	5	2
3	\N	\N	\N	---\n:ref: refs/heads/production\n:before: '00000000'\n:after: 0c118cfba876b98c2872d7e419bb0383782977ff\n	1	2015-01-19 02:08:41.556035	2015-01-19 02:08:41.556035	5	2
4	\N	\N	\N	---\n:ref: refs/heads/development\n:before: '00000000'\n:after: 0c118cfba876b98c2872d7e419bb0383782977ff\n	1	2015-01-19 02:09:10.570015	2015-01-19 02:09:10.570015	5	2
5	\N	\N	\N	---\n:ref: refs/heads/test\n:before: '00000000'\n:after: 0c118cfba876b98c2872d7e419bb0383782977ff\n	1	2015-01-19 02:09:26.015014	2015-01-19 02:09:26.015014	5	2
6	\N	\N	\N	---\n:ref: refs/heads/master\n:before: 0c118cfba876b98c2872d7e419bb0383782977ff\n:after: '00000000'\n	1	2015-01-19 02:11:00.485023	2015-01-19 02:11:00.485023	5	2
7	\N	\N	\N	---\n:before: 0c118cfba876b98c2872d7e419bb0383782977ff\n:after: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n:ref: refs/heads/development\n:user_id: 2\n:user_name: puppet\n:project_id: 1\n:repository:\n  :name: puppet-repository\n  :url: git@gitlab.local.vm:puppet/puppet-repository.git\n  :description: Puppet control repository\n  :homepage: http://gitlab.local.vm/puppet/puppet-repository\n:commits:\n- :id: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :message: |\n    add deps to puppetfile\n  :timestamp: '2015-02-08T15:52:04-08:00'\n  :url: http://gitlab.local.vm/puppet/puppet-repository/commit/3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :author:\n    :name: puppet\n    :email: puppet@gitlab.local\n:total_commits_count: 1\n	1	2015-02-08 23:53:15.159237	2015-02-08 23:53:15.159237	5	2
8	\N	\N	\N	---\n:before: 0c118cfba876b98c2872d7e419bb0383782977ff\n:after: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n:ref: refs/heads/production\n:user_id: 2\n:user_name: puppet\n:project_id: 1\n:repository:\n  :name: puppet-repository\n  :url: git@gitlab.local.vm:puppet/puppet-repository.git\n  :description: Puppet control repository\n  :homepage: http://gitlab.local.vm/puppet/puppet-repository\n:commits:\n- :id: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :message: |\n    add deps to puppetfile\n  :timestamp: '2015-02-08T15:52:04-08:00'\n  :url: http://gitlab.local.vm/puppet/puppet-repository/commit/3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :author:\n    :name: puppet\n    :email: puppet@gitlab.local\n:total_commits_count: 1\n	1	2015-02-08 23:53:15.211812	2015-02-08 23:53:15.211812	5	2
9	\N	\N	\N	---\n:before: 0c118cfba876b98c2872d7e419bb0383782977ff\n:after: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n:ref: refs/heads/test\n:user_id: 2\n:user_name: puppet\n:project_id: 1\n:repository:\n  :name: puppet-repository\n  :url: git@gitlab.local.vm:puppet/puppet-repository.git\n  :description: Puppet control repository\n  :homepage: http://gitlab.local.vm/puppet/puppet-repository\n:commits:\n- :id: 3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :message: |\n    add deps to puppetfile\n  :timestamp: '2015-02-08T15:52:04-08:00'\n  :url: http://gitlab.local.vm/puppet/puppet-repository/commit/3792ad6c3a2d30b4c2936ed4a2be6b8d6c9b9fbe\n  :author:\n    :name: puppet\n    :email: puppet@gitlab.local\n:total_commits_count: 1\n	1	2015-02-08 23:53:15.235452	2015-02-08 23:53:15.235452	5	2
\.


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('events_id_seq', 9, true);


--
-- Data for Name: forked_project_links; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY forked_project_links (id, forked_to_project_id, forked_from_project_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: forked_project_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('forked_project_links_id_seq', 1, false);


--
-- Data for Name: identities; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY identities (id, extern_uid, provider, user_id) FROM stdin;
\.


--
-- Name: identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('identities_id_seq', 1, false);


--
-- Data for Name: issues; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY issues (id, title, assignee_id, author_id, project_id, created_at, updated_at, "position", branch_name, description, milestone_id, state, iid) FROM stdin;
\.


--
-- Name: issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('issues_id_seq', 1, false);


--
-- Data for Name: keys; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY keys (id, user_id, created_at, updated_at, key, title, type, fingerprint) FROM stdin;
1	2	2015-01-19 02:04:35.475192	2015-01-19 02:04:35.475192	ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC7BBE9nilN0p1cJKTf12XF/eUr+9hk+wyXV5H5D/FobuL5ScP78sx+miTIHRQqnlGKaaN85zg9F4xp5Rcav2hW4qHoUHTir8pJEoqzrv6Zqq/Mt4wFbbwvDJMN255hGKcf4KQJyi42OTf+YfGnNGMDjLPDxm+xTWwkGIe6/S5hLhBuqsT+4YTFoO3GP7VWL7k0zxSMvDcJdS8ZuFNWdDzTHWSBz4PnMDi/PHjgF1Mnd99UvLwSddCS0XW3YzAvNHeBcDf5pJvR0mPgPRWg3quAcX3rjOP+K7KWdMUKWWQa9P3heBLx96R2EcXrnFzX4IAvPVf3nJF/n+3D6OiwZkBl rob@marvin.local	demo	\N	4f:0c:3a:63:af:6b:94:90:ab:84:81:b9:f4:64:d6:ad
\.


--
-- Name: keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('keys_id_seq', 1, true);


--
-- Data for Name: label_links; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY label_links (id, label_id, target_id, target_type, created_at, updated_at) FROM stdin;
\.


--
-- Name: label_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('label_links_id_seq', 1, false);


--
-- Data for Name: labels; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY labels (id, title, color, project_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('labels_id_seq', 1, false);


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY members (id, access_level, source_id, source_type, user_id, notification_level, type, created_at, updated_at) FROM stdin;
1	40	1	Project	2	3	ProjectMember	2015-01-19 02:03:13.632582	2015-01-19 02:03:13.632582
\.


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('members_id_seq', 1, true);


--
-- Data for Name: merge_request_diffs; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY merge_request_diffs (id, state, st_commits, st_diffs, merge_request_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: merge_request_diffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('merge_request_diffs_id_seq', 1, false);


--
-- Data for Name: merge_requests; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY merge_requests (id, target_branch, source_branch, source_project_id, author_id, assignee_id, title, created_at, updated_at, milestone_id, state, merge_status, target_project_id, iid, description, "position", locked_at) FROM stdin;
\.


--
-- Name: merge_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('merge_requests_id_seq', 1, false);


--
-- Data for Name: milestones; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY milestones (id, title, project_id, description, due_date, created_at, updated_at, state, iid) FROM stdin;
\.


--
-- Name: milestones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('milestones_id_seq', 1, false);


--
-- Data for Name: namespaces; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY namespaces (id, name, path, owner_id, created_at, updated_at, type, description, avatar) FROM stdin;
1	root	root	1	2015-01-19 01:46:16.008511	2015-01-19 01:46:16.008511	\N		\N
2	puppet	puppet	2	2015-01-19 01:47:20.033088	2015-01-19 01:47:20.033088	\N		\N
\.


--
-- Name: namespaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('namespaces_id_seq', 2, true);


--
-- Data for Name: notes; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY notes (id, note, noteable_type, author_id, created_at, updated_at, project_id, attachment, line_code, commit_id, noteable_id, system, st_diff) FROM stdin;
\.


--
-- Name: notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('notes_id_seq', 1, false);


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY projects (id, name, path, description, created_at, updated_at, creator_id, issues_enabled, wall_enabled, merge_requests_enabled, wiki_enabled, namespace_id, issues_tracker, issues_tracker_id, snippets_enabled, last_activity_at, import_url, visibility_level, archived, import_status, repository_size, star_count) FROM stdin;
1	puppet-repository	puppet-repository	Puppet control repository	2015-01-19 02:03:12.539755	2015-02-08 23:53:15.107814	2	t	f	t	t	2	gitlab	\N	f	2015-02-08 23:53:15.235452		0	f	none	0.100000000000000006	0
\.


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('projects_id_seq', 1, true);


--
-- Data for Name: protected_branches; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY protected_branches (id, project_id, name, created_at, updated_at) FROM stdin;
2	1	production	2015-01-19 02:09:53.424312	2015-01-19 02:09:53.424312
\.


--
-- Name: protected_branches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('protected_branches_id_seq', 2, true);


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY schema_migrations (version) FROM stdin;
20141205134006
20130821090530
20121220064453
20130319214458
20130102143055
20130614132337
20130110172407
20130419190306
20130123114545
20130617095603
20130125090214
20130506085413
20130131070232
20130506090604
20130206084024
20130622115340
20130207104426
20130506095501
20130211085435
20130323174317
20130214154045
20130926081215
20130218140952
20130624162710
20130218141038
20130804151314
20130218141117
20130522141856
20130218141258
20130324151736
20130218141327
20130324172327
20130218141344
20130528184641
20130218141444
20130809124851
20130218141507
20130611210815
20130218141536
20130613165816
20130218141554
20130403003950
20130220124204
20130404164628
20130220125544
20130410175022
20130220125545
20130326142630
20130220133245
20131005191208
20130304104623
20130812143708
20130304104740
20130819182730
20130304105317
20131009115346
20130315124931
20130318212250
20130324203535
20130613173246
20130325173941
20140122122549
20140122114406
20130621195223
20130821090531
20130909132950
20131106151520
20131112114325
20131112220935
20131129154016
20131130165425
20131202192556
20131214224427
20131217102743
20140116231608
20140122112253
20140127170938
20140209025651
20140214102325
20140914173417
20140304005354
20141007100818
20140305193308
20141121133009
20140312145357
20141121161704
20140313092127
20140407135544
20141006143943
20140414131055
20140415124820
20140416074002
20140416185734
20140428105831
20140502115131
20140502125220
20140611135229
20140625115202
20140729134820
20140729140420
20140729145339
20140729152420
20140730111702
20140903115954
20140907220153
20140914113604
20140914145549
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY services (id, type, title, project_id, created_at, updated_at, active, properties) FROM stdin;
\.


--
-- Name: services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('services_id_seq', 1, false);


--
-- Data for Name: snippets; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY snippets (id, title, content, author_id, project_id, created_at, updated_at, file_name, expires_at, type, visibility_level) FROM stdin;
\.


--
-- Name: snippets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('snippets_id_seq', 1, false);


--
-- Data for Name: taggings; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY taggings (id, tag_id, taggable_id, taggable_type, tagger_id, tagger_type, context, created_at) FROM stdin;
\.


--
-- Name: taggings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('taggings_id_seq', 1, false);


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY tags (id, name) FROM stdin;
\.


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('tags_id_seq', 1, false);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, created_at, updated_at, name, admin, projects_limit, skype, linkedin, twitter, authentication_token, theme_id, bio, failed_attempts, locked_at, username, can_create_group, can_create_team, state, color_scheme_id, notification_level, password_expires_at, created_by_id, last_credential_check_at, avatar, confirmation_token, confirmed_at, confirmation_sent_at, unconfirmed_email, hide_no_ssh_key, website_url) FROM stdin;
1	admin@example.com	$2a$10$sLlIUki/95.29200rDglR.6fEuRT/CDPvg0NFsmu3Nbek7afNIUYO	\N	\N	\N	0	\N	\N	\N	\N	2015-01-19 01:46:15.638175	2015-01-19 01:47:19.636184	Administrator	t	10000				mxKCg3dAQstgzqspELFa	2	\N	0	\N	root	t	f	active	1	1	2016-01-19 01:47:19.606306	\N	\N	\N	\N	2015-01-19 01:46:16.021333	2015-01-19 01:46:15.83989	\N	f	
2	puppet@gitlab.local	$2a$10$TQJzJn4GJvPwrM4TnKRq7eOTtMkDmd7sLMisfHrSDM/xqt7vY3Buq	\N	\N	\N	2	2015-02-08 23:44:49.643643	2015-01-19 02:02:03.547564	127.0.0.1	127.0.0.1	2015-01-19 01:47:19.779001	2015-02-08 23:44:49.648867	puppet	f	100				mxKCg3dAQstgzqspELFb	2	\N	0	\N	puppet	t	f	active	1	1	2016-01-19 01:47:19.76805	\N	\N	\N	\N	2015-01-19 01:47:20.068595	2015-01-19 01:47:19.979771	\N	f	
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('users_id_seq', 2, true);


--
-- Data for Name: users_star_projects; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY users_star_projects (id, project_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: users_star_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('users_star_projects_id_seq', 1, false);


--
-- Data for Name: web_hooks; Type: TABLE DATA; Schema: public; Owner: gitlab
--

COPY web_hooks (id, url, project_id, created_at, updated_at, type, service_id, push_events, issues_events, merge_requests_events, tag_push_events) FROM stdin;
\.


--
-- Name: web_hooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gitlab
--

SELECT pg_catalog.setval('web_hooks_id_seq', 1, false);


--
-- Name: broadcast_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY broadcast_messages
    ADD CONSTRAINT broadcast_messages_pkey PRIMARY KEY (id);


--
-- Name: deploy_keys_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY deploy_keys_projects
    ADD CONSTRAINT deploy_keys_projects_pkey PRIMARY KEY (id);


--
-- Name: emails_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY emails
    ADD CONSTRAINT emails_pkey PRIMARY KEY (id);


--
-- Name: events_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: forked_project_links_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY forked_project_links
    ADD CONSTRAINT forked_project_links_pkey PRIMARY KEY (id);


--
-- Name: identities_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- Name: issues_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY issues
    ADD CONSTRAINT issues_pkey PRIMARY KEY (id);


--
-- Name: keys_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY keys
    ADD CONSTRAINT keys_pkey PRIMARY KEY (id);


--
-- Name: label_links_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY label_links
    ADD CONSTRAINT label_links_pkey PRIMARY KEY (id);


--
-- Name: labels_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY labels
    ADD CONSTRAINT labels_pkey PRIMARY KEY (id);


--
-- Name: members_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: merge_request_diffs_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY merge_request_diffs
    ADD CONSTRAINT merge_request_diffs_pkey PRIMARY KEY (id);


--
-- Name: merge_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY merge_requests
    ADD CONSTRAINT merge_requests_pkey PRIMARY KEY (id);


--
-- Name: milestones_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY milestones
    ADD CONSTRAINT milestones_pkey PRIMARY KEY (id);


--
-- Name: namespaces_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY namespaces
    ADD CONSTRAINT namespaces_pkey PRIMARY KEY (id);


--
-- Name: notes_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY notes
    ADD CONSTRAINT notes_pkey PRIMARY KEY (id);


--
-- Name: projects_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: protected_branches_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY protected_branches
    ADD CONSTRAINT protected_branches_pkey PRIMARY KEY (id);


--
-- Name: services_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: snippets_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY snippets
    ADD CONSTRAINT snippets_pkey PRIMARY KEY (id);


--
-- Name: taggings_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY taggings
    ADD CONSTRAINT taggings_pkey PRIMARY KEY (id);


--
-- Name: tags_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_star_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY users_star_projects
    ADD CONSTRAINT users_star_projects_pkey PRIMARY KEY (id);


--
-- Name: web_hooks_pkey; Type: CONSTRAINT; Schema: public; Owner: gitlab; Tablespace: 
--

ALTER TABLE ONLY web_hooks
    ADD CONSTRAINT web_hooks_pkey PRIMARY KEY (id);


--
-- Name: index_deploy_keys_projects_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_deploy_keys_projects_on_project_id ON deploy_keys_projects USING btree (project_id);


--
-- Name: index_emails_on_email; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_emails_on_email ON emails USING btree (email);


--
-- Name: index_emails_on_user_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_emails_on_user_id ON emails USING btree (user_id);


--
-- Name: index_events_on_action; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_action ON events USING btree (action);


--
-- Name: index_events_on_author_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_author_id ON events USING btree (author_id);


--
-- Name: index_events_on_created_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_created_at ON events USING btree (created_at);


--
-- Name: index_events_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_project_id ON events USING btree (project_id);


--
-- Name: index_events_on_target_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_target_id ON events USING btree (target_id);


--
-- Name: index_events_on_target_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_events_on_target_type ON events USING btree (target_type);


--
-- Name: index_forked_project_links_on_forked_to_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_forked_project_links_on_forked_to_project_id ON forked_project_links USING btree (forked_to_project_id);


--
-- Name: index_identities_on_user_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_identities_on_user_id ON identities USING btree (user_id);


--
-- Name: index_issues_on_assignee_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_assignee_id ON issues USING btree (assignee_id);


--
-- Name: index_issues_on_author_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_author_id ON issues USING btree (author_id);


--
-- Name: index_issues_on_created_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_created_at ON issues USING btree (created_at);


--
-- Name: index_issues_on_milestone_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_milestone_id ON issues USING btree (milestone_id);


--
-- Name: index_issues_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_project_id ON issues USING btree (project_id);


--
-- Name: index_issues_on_project_id_and_iid; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_issues_on_project_id_and_iid ON issues USING btree (project_id, iid);


--
-- Name: index_issues_on_title; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_issues_on_title ON issues USING btree (title);


--
-- Name: index_keys_on_user_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_keys_on_user_id ON keys USING btree (user_id);


--
-- Name: index_label_links_on_label_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_label_links_on_label_id ON label_links USING btree (label_id);


--
-- Name: index_label_links_on_target_id_and_target_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_label_links_on_target_id_and_target_type ON label_links USING btree (target_id, target_type);


--
-- Name: index_labels_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_labels_on_project_id ON labels USING btree (project_id);


--
-- Name: index_members_on_access_level; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_members_on_access_level ON members USING btree (access_level);


--
-- Name: index_members_on_source_id_and_source_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_members_on_source_id_and_source_type ON members USING btree (source_id, source_type);


--
-- Name: index_members_on_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_members_on_type ON members USING btree (type);


--
-- Name: index_members_on_user_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_members_on_user_id ON members USING btree (user_id);


--
-- Name: index_merge_request_diffs_on_merge_request_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_merge_request_diffs_on_merge_request_id ON merge_request_diffs USING btree (merge_request_id);


--
-- Name: index_merge_requests_on_assignee_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_assignee_id ON merge_requests USING btree (assignee_id);


--
-- Name: index_merge_requests_on_author_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_author_id ON merge_requests USING btree (author_id);


--
-- Name: index_merge_requests_on_created_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_created_at ON merge_requests USING btree (created_at);


--
-- Name: index_merge_requests_on_milestone_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_milestone_id ON merge_requests USING btree (milestone_id);


--
-- Name: index_merge_requests_on_source_branch; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_source_branch ON merge_requests USING btree (source_branch);


--
-- Name: index_merge_requests_on_source_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_source_project_id ON merge_requests USING btree (source_project_id);


--
-- Name: index_merge_requests_on_target_branch; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_target_branch ON merge_requests USING btree (target_branch);


--
-- Name: index_merge_requests_on_target_project_id_and_iid; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_merge_requests_on_target_project_id_and_iid ON merge_requests USING btree (target_project_id, iid);


--
-- Name: index_merge_requests_on_title; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_merge_requests_on_title ON merge_requests USING btree (title);


--
-- Name: index_milestones_on_due_date; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_milestones_on_due_date ON milestones USING btree (due_date);


--
-- Name: index_milestones_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_milestones_on_project_id ON milestones USING btree (project_id);


--
-- Name: index_milestones_on_project_id_and_iid; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_milestones_on_project_id_and_iid ON milestones USING btree (project_id, iid);


--
-- Name: index_namespaces_on_name; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_namespaces_on_name ON namespaces USING btree (name);


--
-- Name: index_namespaces_on_owner_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_namespaces_on_owner_id ON namespaces USING btree (owner_id);


--
-- Name: index_namespaces_on_path; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_namespaces_on_path ON namespaces USING btree (path);


--
-- Name: index_namespaces_on_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_namespaces_on_type ON namespaces USING btree (type);


--
-- Name: index_notes_on_author_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_author_id ON notes USING btree (author_id);


--
-- Name: index_notes_on_commit_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_commit_id ON notes USING btree (commit_id);


--
-- Name: index_notes_on_created_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_created_at ON notes USING btree (created_at);


--
-- Name: index_notes_on_noteable_id_and_noteable_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_noteable_id_and_noteable_type ON notes USING btree (noteable_id, noteable_type);


--
-- Name: index_notes_on_noteable_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_noteable_type ON notes USING btree (noteable_type);


--
-- Name: index_notes_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_project_id ON notes USING btree (project_id);


--
-- Name: index_notes_on_project_id_and_noteable_type; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_project_id_and_noteable_type ON notes USING btree (project_id, noteable_type);


--
-- Name: index_notes_on_updated_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_notes_on_updated_at ON notes USING btree (updated_at);


--
-- Name: index_projects_on_creator_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_projects_on_creator_id ON projects USING btree (creator_id);


--
-- Name: index_projects_on_last_activity_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_projects_on_last_activity_at ON projects USING btree (last_activity_at);


--
-- Name: index_projects_on_namespace_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_projects_on_namespace_id ON projects USING btree (namespace_id);


--
-- Name: index_projects_on_star_count; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_projects_on_star_count ON projects USING btree (star_count);


--
-- Name: index_protected_branches_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_protected_branches_on_project_id ON protected_branches USING btree (project_id);


--
-- Name: index_services_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_services_on_project_id ON services USING btree (project_id);


--
-- Name: index_snippets_on_author_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_snippets_on_author_id ON snippets USING btree (author_id);


--
-- Name: index_snippets_on_created_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_snippets_on_created_at ON snippets USING btree (created_at);


--
-- Name: index_snippets_on_expires_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_snippets_on_expires_at ON snippets USING btree (expires_at);


--
-- Name: index_snippets_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_snippets_on_project_id ON snippets USING btree (project_id);


--
-- Name: index_snippets_on_visibility_level; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_snippets_on_visibility_level ON snippets USING btree (visibility_level);


--
-- Name: index_taggings_on_tag_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_taggings_on_tag_id ON taggings USING btree (tag_id);


--
-- Name: index_taggings_on_taggable_id_and_taggable_type_and_context; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_taggings_on_taggable_id_and_taggable_type_and_context ON taggings USING btree (taggable_id, taggable_type, context);


--
-- Name: index_users_on_admin; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_on_admin ON users USING btree (admin);


--
-- Name: index_users_on_authentication_token; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_authentication_token ON users USING btree (authentication_token);


--
-- Name: index_users_on_confirmation_token; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_confirmation_token ON users USING btree (confirmation_token);


--
-- Name: index_users_on_current_sign_in_at; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_on_current_sign_in_at ON users USING btree (current_sign_in_at);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_name; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_on_name ON users USING btree (name);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON users USING btree (reset_password_token);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_on_username ON users USING btree (username);


--
-- Name: index_users_star_projects_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_star_projects_on_project_id ON users_star_projects USING btree (project_id);


--
-- Name: index_users_star_projects_on_user_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_users_star_projects_on_user_id ON users_star_projects USING btree (user_id);


--
-- Name: index_users_star_projects_on_user_id_and_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX index_users_star_projects_on_user_id_and_project_id ON users_star_projects USING btree (user_id, project_id);


--
-- Name: index_web_hooks_on_project_id; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE INDEX index_web_hooks_on_project_id ON web_hooks USING btree (project_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: gitlab; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: gitlab-psql
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM "gitlab-psql";
GRANT ALL ON SCHEMA public TO "gitlab-psql";
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

